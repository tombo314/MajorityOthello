・ＰＣの省電力モードを解除する
<br>
　　-> setInterval の間隔がバグるため
<br>
・画面幅を調整する
<br>
　　-> レスポンシブ性が低いため
<br>
　　-> main.scss, wait.scss, battle.scss で $release: true のとき、画面幅が正しくない場合にメッセージを表示